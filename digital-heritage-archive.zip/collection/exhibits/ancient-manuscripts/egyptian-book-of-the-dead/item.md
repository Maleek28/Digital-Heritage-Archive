# Egyptian Book of the Dead

The Egyptian Book of the Dead is a collection of funerary texts used from the beginning of the New Kingdom (around 1550 BCE) to help guide the dead through the underworld and into the afterlife.

The text includes spells, incantations, and illustrations, often written on papyrus and placed in tombs.

## Highlights
- Written in hieroglyphs
- Used across centuries by different classes of Egyptian society
- Spells vary between copies
