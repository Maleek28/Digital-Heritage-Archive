# Dresden Codex

The Dresden Codex is one of the few surviving pre-Columbian Maya books. It contains astronomical calculations, ritual schedules, and calendar systems and was used by priests for divination.

Discovered in the 18th century, it’s named after the library in Dresden, Germany, where it is currently housed.

## Highlights
- Written in Mayan hieroglyphs
- Dates from the 11th–12th century CE
- One of only four surviving Maya codices
