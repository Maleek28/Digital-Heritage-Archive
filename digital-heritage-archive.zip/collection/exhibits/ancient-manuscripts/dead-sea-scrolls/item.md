# Dead Sea Scrolls

The Dead Sea Scrolls are a collection of Jewish texts discovered in the Qumran Caves near the Dead Sea, dating from the 3rd century BCE to the 1st century CE. They include the earliest known copies of biblical texts and documents from the Second Temple period.

## Highlights
- Over 900 manuscripts
- Written in Hebrew, Aramaic, and Greek
- Include biblical texts, sectarian writings, and apocrypha
