# Gutenberg Bible

The Gutenberg Bible, also known as the 42-line Bible, was among the earliest major books printed using mass-produced movable metal type in Europe. It marked the start of the "Gutenberg Revolution" and the age of the printed book in the West.

This copy was completed around 1455 in Mainz, Germany, by Johannes Gutenberg. Only 49 known copies or substantial portions survive today, many preserved in academic institutions.

## Highlights
- Language: Latin
- Printed on paper and vellum
- Two volumes
- Lavish illumination in some editions
